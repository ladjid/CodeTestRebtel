﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CodeTestRebtel.Client.Tests
{
    public class Class1
    {
    }
}
