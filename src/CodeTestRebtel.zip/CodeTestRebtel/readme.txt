CodeTestRebtel
==============
Implemented using MVC 4 and Angular JS
Used Ninject for managing dependency injections
Used mspec for unit testing CodeTestRebtel.Data
Used FakeItEasy for mocking up contracts
Used bootstrap for basic styling like buttons
Used my own created CSS file for styling as well.
Used QUnit for testing Angular JavaScript controllers and services
Use this link (Path to your web server)/QunitTestRunner  to run the angular unit tests
The unit tests are located in the following folder Scripts/Tests 

Code Test Rebtel
